module.exports = async client => {
  console.log('0-ready');
};
