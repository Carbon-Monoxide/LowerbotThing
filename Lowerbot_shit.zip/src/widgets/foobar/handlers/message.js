module.exports = async message => {
    if (message.attachments.size > 0) {
        message.attachments.forEach(Attachment => {
            console.log(`\n(2) IMAGELOGS - [${message.guild}] ${message.author.tag}-Url:\n${Attachment.url}\n`)
        })
    } else {
        if (message.guild === null) {
			console.log(`\n(1) CHATLOGS - [DM] ${message.author.tag}: ${message.content}`)
		} else {
			console.log(`\n(1) CHATLOGS - [${message.guild}] ${message.author.tag}: ${message.content}`);
		}
    }
};