module.exports = {
  name: 'getping',
  aliases: ['tp'],
  ownersOnly: false,
  guildOnly: false,
  requireArgs: false,
  deleteCommand: false,
  cooldown: 10,
  disabled: false,
  messageExecute: async (message, args) =>
    message.channel.send(`Bot ping is ${Math.round(message.client.ws.ping)}ms`)
};