module.exports = {
  name: 'nword',
  aliases: ['niggaword', 'nibbaword', 'niggerword', 'theepicword'],
  ownersOnly: false,
  guildOnly: false,
  requireArgs: false,
  deleteCommand: false,
  cooldown: 4,
  disabled: false,
  messageExecute: async (message, args) =>
    message.channel.send(`**yuo:** I WILL SAY THE N WORD **me epicly**: nO yOU CANT SAY THAT THATSS RACIYSST, MS. OBAMA GET DOW- *explosion*!!!1!11!!!!1`)
};
