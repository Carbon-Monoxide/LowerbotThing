module.exports = {
  prefixes: [';'],
  commandDelimiter: ',,',
  commandLimit: 3,
  owners: ['544877144464162816']
};
