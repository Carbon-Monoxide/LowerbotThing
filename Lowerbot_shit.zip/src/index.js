﻿// IMPORTANT CONST's DO NOT DELETE
const Discord = require("discord.js")
const client = new Discord.Client()

require('./core/loadWidgetListeners')(client); // gets all the commands in .\scr\widgets\command\commands\

client.on("ready", () => {
  console.log(`Logged in as ${client.user.tag}!`) // Logs when bot is logged in.
})

function hasUpperCase(str) {
    return (/[A-Z]/.test(str)); // tests if a string has uppercase characters
}

const helpEmbed1 = new Discord.MessageEmbed() // creates helpEmbed1
	// --------------------------------------------------------------------------------------------------------------------------------
	.setColor('#0099ff')
	.setTitle('Click to join the Lowercase subreddit!')
	.setURL('https://shorturl.at/dhmzT')
	.setAuthor('Bot made by ZENWARUDO!#4633', 'https://i.imgur.com/rx0u4rB.png', 'https://shorturl.at/dhmzT')
	.setDescription('Main Help Embed:')
	.setThumbnail('https://i.imgur.com/Op4PoPy.png')
	.addFields(
	// main important commands and more
		{ name: '**Main commands:**', value: '• ;getping *(or)* ;tp: Returns client ping.\n• ;help, ;helpme *(or)* ;?: Displays list of commands.' },
		{ name: '\u200B', value: '\u200B' },
		{ name: '**Command usages:**', value: '• ;help *(cat[main,fun])*\n• ;getping *(no args)*', inline: true },
	)
	.setImage('https://i.imgur.com/dsDXzOR.png')
	.setTimestamp()
	.setFooter('if ur reading this u have smol brain :xd:', 'https://i.imgur.com/rx0u4rB.png');
	// --------------------------------------------------------------------------------------------------------------------------------
const helpEmbed2 = new Discord.MessageEmbed() // creates helpEmbed2
	// --------------------------------------------------------------------------------------------------------------------------------
	.setColor('#ff69b4')
	.setTitle('Click to join the Lowercase subreddit!')
	.setURL('https://shorturl.at/dhmzT')
	.setAuthor('Bot made by ZENWARUDO!#4633', 'https://i.imgur.com/rx0u4rB.png', 'https://shorturl.at/dhmzT')
	.setDescription('Fun Help Embed:')
	.setThumbnail('https://i.imgur.com/Op4PoPy.png')
	.addFields(
	// main important commands and more
		{ name: '**Fun Commands:**', value: '• ;say: Repeats back to you what you just said. (Censoring lvl: Light)\n• ;cal *(or)* ;calculate: calculates the answer to an equation\n• ;sayraw: Repeats back to you what you say after ;sayraw but with no mention (Censoring lvl: Moderate)' },
		{ name: '\u200B', value: '\u200B' },
		{ name: '**Command usages:**', value: '• ;cal *(x op y)*\n• ;say *(msg)*', inline: true },
	)
	.setImage('https://i.imgur.com/WqDnd3t.png')
	.setTimestamp()
	.setFooter('if ur reading this u have smol pp :xd:', 'https://i.imgur.com/rx0u4rB.png');
	// --------------------------------------------------------------------------------------------------------------------------------
client.on("message", msg => { // When user sends chat message
	var content = msg.content.toLowerCase()
	if (content === ";help main" || content === ";helpme main" || content === ";?") { // help command
		msg.channel.send(helpEmbed1) 
	} else if (content === ";help fun" || content === ";helpme fun") {
		msg.channel.send(helpEmbed2)
	} else if (content === "snoopdogpenisniggafaggot") { // easter egg command #1
		msg.channel.send("n o")
	} else if (content.startsWith(";say ") && (msg.author.bot === false)) { // say command
		if (content.includes("zen") && (content.includes("gay") || content.includes("homosexual")) || content.includes("weeb")) {
			msg.reply(`no u <:xd:666094189989199872>`)
		} else if (content.includes("hate ") && content.includes("nigger")){
			msg.reply("You aren't tricking me into saying something racist, dude. Not cool.")
		} else if (content.includes("faggot") || content.includes("fag ") || content.includes("fags")){
			msg.reply("You aren't tricking me into saying something homophobic, dude. Not cool.")
		} else if (content.includes("i have childporn") || content.includes("i have child porn") || content.includes("i have cp") || content.includes("i rape youngins'") || content.includes("i rape children") || content.includes("i rape kids") || content.includes("i rape minors") || content.includes("i rape underage kids")) {
			msg.reply("You aren't tricking me into saying something pedophilic, dude. Not cool.")
		} else {
			msg.reply((msg.content).slice(5))
		}
	} else if (content.startsWith(";sayraw ") && (msg.author.bot === false)) {
		if (content.includes("nigger") || content.includes("nigga") || content.includes("faggot") || content.includes("fags") || content.includes("porn") || content.includes("lewd")) {
			msg.channel.send((((((((msg.content).slice(8)).replace(/nigger/g, '@!$%#&')).replace(/nigga/g, '!@$%#')).replace(/faggot/g, '!@$%#&')).replace(/fags/g, '$@!s')).replace(/porn/g, '%$@!')).replace(/lewd/g, '$#!@'))
		} else {
			msg.channel.send((msg.content).slice(8))
		}
	} else if (content === "<@!690979386354302977>, ping") { // testing command functionality
		if (hasUpperCase(msg.content)) {
			msg.reply("pong! (fuck you)")
		} else {
			msg.reply("pong!")
		}
	} else if (((content === "b") || (msg.content === "A")) && (msg.channel.id === "664924862661394456")) {
		msg.delete()
		msg.channel.send("d i e")
			.then(newMessage => newMessage.delete(2000));
	} else if ((content === "what is our sponsor") || (content === "what's our sponsor") || (content === "whats our sponsor") || (content === "what's the sponsor")) {
		msg.reply("I've never been much of a mobile gamer, but, forget everything you think you know about mobile games because Raid Shadow Legends is one of the most ambitious RPG projects of 2019 has just been released and will change everything. Just look at the level of detail of these characters! If you use the code in the description you can start with 50,000 silver and join the Special Launch Tournament, and you better hurry because it's getting big fast! You can play for totally free with the link below on your smartphone.")
	} else if ((content === "so guys we did it") || (content === "so guys we've done it")) {
		msg.channel.send("So guys, we did it, we reached a quarter of a million subscribers, 250,000 subscribers and still growing the fact that we've reached this number in such a short amount of time is just phenomenal, I'm-I'm just amazed. Thank you all so much for supporting this channel and helping it grow. I-I love you guys... You guys are just awesome.")
	} else if (((content.startsWith(";calculate")) || (content.startsWith(";cal")))) {
		if (content.startsWith(";calculate ")) {
			if (content.length === 16) {
				if (((content).slice(13, 14) === "+")) {
					var x = (Number((content).slice(11, 12)))
					var y = (Number((content).slice(15, 16)))
					msg.reply(`The sum is ${x + y}`)
				} else if (((content).slice(13, 14) === "x") || ((content).slice(13, 14) === "*")) {
					var x = (Number((content).slice(11, 12)))
					var y = (Number((content).slice(15, 16)))
					msg.reply(`The product is ${x * y}`)
				} else if (((content).slice(13, 14) === "-")) {
					var x = (Number((content).slice(11, 12)))
					var y = (Number((content).slice(15, 16)))
					msg.reply(`The difference is ${x - y}`)
				} else if (((content).slice(13, 14) === "÷") || ((content).slice(13, 14) === "/")) {
					var x = (Number((content).slice(11, 12)))
					var y = (Number((content).slice(15, 16)))
					if (x === 0 || y === 0) {
						msg.reply(`Say you have 0 dogs, and you have 0 friends to let pet the dogs, then you have 0 reason to live, because their are 0 dogs to cheer you up, due to your 0 happiness. The answer is 0, you cunt.`)
					} else if (x !== 0 || y === 0) {
						msg.reply(`You can't divide by zero bruh.`)
					} else {
						msg.reply(`The quotient is ${x / y}`)
					}
				}
			}
		} else if (content.startsWith(";cal ")) {
			if (content.length === 10) {
				if (((content).slice(7, 8) === "+")) {
					var x = (Number((content).slice(5, 6)))
					var y = (Number((content).slice(9, 10)))
					msg.reply(`The sum is ${x + y}`)
				} else if (((content).slice(7, 8) === "x") || ((content).slice(7, 8) === "*")) {
					var x = (Number((content).slice(5, 6)))
					var y = (Number((content).slice(9, 10)))
					msg.reply(`The product is ${x * y}`)
				} else if (((content).slice(7, 8) === "-")) {
					var x = (Number((content).slice(5, 6)))
					var y = (Number((content).slice(9, 10)))
					msg.reply(`The difference is ${x - y}`)
				} else if (((content).slice(7, 8) === "÷") || ((content).slice(7, 8) === "/")) {
					var x = (Number((content).slice(5, 6)))
					var y = (Number((content).slice(9, 10)))
					if (x == 0 && y == 0) {
						msg.reply(`Say you have 0 dogs, and you have 0 friends to let pet the dogs, then you have 0 reason to live, because their are 0 dogs to cheer you up, due to your 0 happiness. The answer is 0, you cunt.`)
					} else if (x != 0 && y == 0) {
						msg.reply(`You can't divide by zero bruh.`)
					} else {
						msg.reply(`The quotient is ${x / y}`)
					}
				}
			}
		}
	} else if (content === ";clearlog" || content === ";cl") {
		if (msg.author.id === "544877144464162816") {
			msg.channel.send("Log cleared.")
			console.clear()
		}
	}
})
client.on('guildMemberAdd', member => {
	member.send(`Hello, {member.tag}`)
});
// Custom presence.
client.on('ready', () => {
	client.user.setActivity('you masturbate uwu', { type: 'WATCHING' });
	console.log(`${client.user.username} is fully active.`);
	let guilds = client.guilds.cache.map(guild => guild.id) // for discord v11 //let guilds = client.guilds.map(guild => guild.id)
    console.log(guilds)
})
// Private token don't share
client.login("CENSORED")